/* MIT License — Escape Room Asset Pack contributors */
(function (root) {
  'use strict';
  class BatSprite {
    constructor(image, atlas, animation = 'fly_down') {
      this.image = image;
      this.atlas = atlas;
      this.play(animation);
    }
    play(name) {
      if (!this.atlas.animations[name]) throw new Error('Unknown animation: ' + name);
      this.animation = name;
      this.elapsed = 0;
    }
    update(deltaMs) {
      if (Number.isFinite(deltaMs) && deltaMs >= 0) this.elapsed += deltaMs;
    }
    get frameName() {
      const a = this.atlas.animations[this.animation];
      const step = Math.floor(this.elapsed / a.frameDurationMs);
      return a.frames[a.loop ? step % a.frames.length : Math.min(step, a.frames.length - 1)];
    }
    draw(ctx, x, y, scale = 3) {
      const entry = this.atlas.frames[this.frameName];
      const f = entry.frame;
      const p = entry.pivot;
      const previous = ctx.imageSmoothingEnabled;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(this.image, f.x, f.y, f.w, f.h,
        Math.round(x - f.w * scale * p.x), Math.round(y - f.h * scale * p.y),
        f.w * scale, f.h * scale);
      ctx.imageSmoothingEnabled = previous;
    }
  }
  root.BatSprite = BatSprite;
  if (typeof module !== 'undefined' && module.exports) module.exports = BatSprite;
})(typeof window !== 'undefined' ? window : globalThis);
