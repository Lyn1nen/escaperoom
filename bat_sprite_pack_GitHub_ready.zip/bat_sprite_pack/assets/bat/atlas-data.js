window.BAT_ATLAS = {
  "frames": {
    "fly_down_00.png": {
      "frame": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_down_01.png": {
      "frame": {
        "x": 64,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_down_02.png": {
      "frame": {
        "x": 128,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_down_03.png": {
      "frame": {
        "x": 192,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_left_00.png": {
      "frame": {
        "x": 0,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_left_01.png": {
      "frame": {
        "x": 64,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_left_02.png": {
      "frame": {
        "x": 128,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_left_03.png": {
      "frame": {
        "x": 192,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_right_00.png": {
      "frame": {
        "x": 0,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_right_01.png": {
      "frame": {
        "x": 64,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_right_02.png": {
      "frame": {
        "x": 128,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_right_03.png": {
      "frame": {
        "x": 192,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_up_00.png": {
      "frame": {
        "x": 0,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_up_01.png": {
      "frame": {
        "x": 64,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_up_02.png": {
      "frame": {
        "x": 128,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "fly_up_03.png": {
      "frame": {
        "x": 192,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "hang_00.png": {
      "frame": {
        "x": 0,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "hang_01.png": {
      "frame": {
        "x": 64,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "hang_02.png": {
      "frame": {
        "x": 128,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "hang_03.png": {
      "frame": {
        "x": 192,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_00.png": {
      "frame": {
        "x": 0,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_01.png": {
      "frame": {
        "x": 64,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_02.png": {
      "frame": {
        "x": 128,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_03.png": {
      "frame": {
        "x": 192,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    }
  },
  "animations": {
    "fly_down": {
      "label": "向下飛行",
      "row": 0,
      "frames": [
        "fly_down_00.png",
        "fly_down_01.png",
        "fly_down_02.png",
        "fly_down_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "fly_left": {
      "label": "向左飛行",
      "row": 1,
      "frames": [
        "fly_left_00.png",
        "fly_left_01.png",
        "fly_left_02.png",
        "fly_left_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "fly_right": {
      "label": "向右飛行",
      "row": 2,
      "frames": [
        "fly_right_00.png",
        "fly_right_01.png",
        "fly_right_02.png",
        "fly_right_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "fly_up": {
      "label": "向上飛行",
      "row": 3,
      "frames": [
        "fly_up_00.png",
        "fly_up_01.png",
        "fly_up_02.png",
        "fly_up_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "hang": {
      "label": "倒掛休息",
      "row": 4,
      "frames": [
        "hang_00.png",
        "hang_01.png",
        "hang_02.png",
        "hang_03.png"
      ],
      "frameDurationMs": 300,
      "loop": true
    },
    "alert": {
      "label": "警戒",
      "row": 5,
      "frames": [
        "alert_00.png",
        "alert_01.png",
        "alert_02.png",
        "alert_03.png"
      ],
      "frameDurationMs": 100,
      "loop": true
    }
  },
  "meta": {
    "app": "Escape Room Bat Sprite Pack",
    "version": "1.0.0",
    "image": "spritesheet_64.png",
    "format": "RGBA8888",
    "size": {
      "w": 256,
      "h": 384
    },
    "scale": "1",
    "grid": {
      "columns": 4,
      "rows": 6,
      "frameWidth": 64,
      "frameHeight": 64,
      "margin": 0,
      "spacing": 0
    }
  },
  "gameplay": {
    "origin": {
      "x": 0.5,
      "y": 0.5
    },
    "suggestedCollider": {
      "type": "circle",
      "x": 32.0,
      "y": 32.0,
      "radius": 9.0
    }
  }
};
