# 圖像製作紀錄

- 製作日期：2026-11-05。
- 由內建圖像生成功能建立原始蝙蝠圖集，保留原始 PNG 與 alpha。
- 遊戲圖匯出採固定 4 × 6 格裁切，每格最近鄰縮放至 56 × 56 px，再置入 64 × 64 px 透明畫布並保留四周 4 px 安全邊界；未重繪角色。
- 128 px 版本為 64 px 版本的最近鄰整數放大。
- GIF 是將匯出格繪於深色背景的展示，不是透明遊戲素材。
- 原圖位於 `source/bat_generated.png`；重建指令見 README。
- 像素風格由 AI 生成，未經人工逐像素校稿。

## 完整生成提示

Use case: stylized-concept. Asset type: pixel-art sprite atlas for a 2D escape-room game. Primary request: ONE complete BAT sprite sheet, exactly FOUR columns and SIX rows, 24 isolated sprites in a perfectly regular invisible grid. Portrait canvas ideally 1024 by 1536, each of the 24 cells square. Transparent background with true alpha. NO writing, no numbers, no border, no gridlines. Subject: same small gothic bat across all frames, charcoal-plum fur, lavender-purple wing membranes with a muted rose inner section, large pointed ears, tiny ivory fangs, small pale amber eyes, clean dark outline. Readable retro 32/64-pixel game style, hard square pixel steps, restrained 12-color palette, no soft lighting or painted gradients, spooky but charming for an escape room. All bats fit COMPLETELY inside their respective cells with at least 15 percent transparent padding on EVERY side even at maximum wingspan. Same character scale and same body anchor in each cell, no wings extending across cell boundaries. Camera is a slightly overhead 2D RPG view. Exact row semantics: Row1: flying toward viewer / screen DOWN, face and chest visible, four wing phases left-to-right: wings raised, spread horizontal, wings down, spread horizontal lifting; show obvious differing wing silhouettes. Row2: flying LEFT in full LEFT profile, nose points LEFT in every frame, four wingbeat phases raised/spread/down/spread lifting. Row3: flying RIGHT in full RIGHT profile, nose points RIGHT in every frame, same four phases. Row4: flying AWAY / screen UP, back and back of ears visible, NO FACE visible, four wingbeat phases raised/spread/down/spread lifting. Row5: HANGING UPSIDE DOWN resting, tiny feet at top and ears and head at bottom, wings wrapped around body, same upside-down pose in all four cells, eyes closed / half-open / open / half-closed. NO branch, hook, rope or supporting prop. Row6: ALERT facing viewer, four successive wing flaps, warmer red eyes, alert expression without any exclamation mark, no effects. Keep body center identical within each row; animate wings rather than translating the bat. No additional characters, no items, no scene, no scenery, no ground shadows, no logos, no watermark, no particles, no UI.

