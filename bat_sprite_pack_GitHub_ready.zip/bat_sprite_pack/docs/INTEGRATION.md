# 遊戲整合說明

## 座標與切片

圖集 4 欄、6 列，圖片原點在左上角。格間距與圖集外框留白皆為 0；每格內部至少保留 4 px 透明安全邊界（64 px 版本）。128 px 版本所有矩形座標與安全邊界為兩倍。

```text
x = column × frameWidth
y = row × frameHeight
index = row × 4 + column
```

每格完整保留，不旋轉、不裁邊；獨立 PNG 的像素與圖集對應格完全一致。`pivot` 使用 0–1 比例，預設 `(0.5, 0.5)`，代表格子中心；它不是逐格量測的蝙蝠軀幹中心。

## JSON 欄位

`frames` / `meta` 採常見 TexturePacker JSON Hash 結構，動畫由本包的 `animations` 擴充欄位定義。部分引擎只會讀取圖集矩形，仍需依 README 表格手動建立動畫。

| 欄位 | 含意 |
| --- | --- |
| `frames[name].frame` | PNG 上的 x、y、w、h，單位像素 |
| `frames[name].pivot` | 繪製原點比例 |
| `animations[name].frames` | 有順序的格名稱陣列 |
| `animations[name].frameDurationMs` | 每格播放時間，單位毫秒 |
| `animations[name].loop` | 是否循環 |
| `gameplay.suggestedCollider` | 格內建議圓形碰撞區，需按場景調整 |

使用 128 px 圖集時須搭配 `atlas_128.json`。JSON 的 `meta.image` 是與 JSON 同資料夾的 PNG 檔名。

## Canvas 範例

在 HTML 載入 `atlas-data.js` 和 `examples/bat-sprite.js`，並在 PNG 載入完成後建立物件：

```js
const bat = new BatSprite(image, BAT_ATLAS, 'fly_down');
// 遊戲事件發生時切換，請勿每個更新迴圈重設動畫。
bat.play('alert');
// 每格更新與繪製
bat.update(deltaMs);
bat.draw(ctx, worldX, worldY, 3);
```

`deltaMs` 單位毫秒。`draw()` 的 x/y 為格子中心。整數放大及關閉影像平滑適合像素風格；鏡頭座標也可取整。

## 密室事件對應

| 事件 | 動畫 | 遊戲端另行實作 |
| --- | --- | --- |
| 飛過走廊 | `fly_*` | 位移、路徑、碰撞 |
| 房間未啟動 | `hang` | 倒掛位置、觸發範圍 |
| 玩家靠近 | `alert` | 距離判斷、音效或對話 |
| 解開機關 | `fly_up` | 離場路徑、線索掉落 |

本素材不包含場景、音效、攻擊判定、尋路或背包系統。碰撞區建議只包住軀幹，避免拍翅時碰撞範圍隨翼展改變；倒掛位置可另外設掛點。

圖像為 AI 生成，可能有細小的輪廓或位置差異。需要嚴格逐像素一致時，請在美術編輯器調整。交付會驗證透明度、格尺寸、動畫參照與範例計時；未宣稱已在特定引擎完成整合測試。
