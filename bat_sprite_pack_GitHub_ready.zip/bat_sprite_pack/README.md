# 蝙蝠 Sprite Sheet・密室逃脫遊戲素材

像素風蝙蝠，提供四方向飛行、倒掛休息與警戒共 **6 組動畫、24 格**。深紫色身體、紫色翼膜、尖耳與小獠牙，適合用於密室中的巡邏生物、視覺提示或機關角色。

![動畫預覽](preview.gif)

## 快速使用

1. 解壓縮，保留 `bat_sprite_pack` 內的資料夾結構。
2. 開啟 `demo/index.html` 可同時預覽六組動畫，暫停或調整速度；無需網路及外部套件。
3. 遊戲使用 `assets/bat/spritesheet_64.png`，切片尺寸 **64 × 64 px**，**4 欄 × 6 列**。圖片匯入時選 Point / Nearest 過濾。
4. 依下表建立動畫，或讀取 `assets/bat/atlas_64.json`。

64 px 版本整張為 **256 × 384 px**。另附 128 px 版本，整張 **512 × 768 px**，是標準版最近鄰 2 倍放大，沒有額外細節。兩個尺寸皆有對應 JSON。

## 動畫表

列與格編號皆從 0 開始；每列由左至右 4 格。所有動畫預設循環。

| 名稱 | 列索引 | 格編號 | 每格時間 | 視覺／用途 |
| --- | ---: | --- | ---: | --- |
| `fly_down` | 0 | 0–3 | 120 ms | 正面朝下飛行、可作懸停拍翅 |
| `fly_left` | 1 | 4–7 | 120 ms | 朝左的側面飛行 |
| `fly_right` | 2 | 8–11 | 120 ms | 朝右的側面飛行 |
| `fly_up` | 3 | 12–15 | 120 ms | 背面朝上飛行 |
| `hang` | 4 | 16–19 | 300 ms | 倒掛、閉眼與睜眼 |
| `alert` | 5 | 20–23 | 100 ms | 正面警戒、紅眼拍翅 |

飛行列只表現拍翅與朝向，角色移動、尋路與碰撞由遊戲程式控制。倒掛列不含樹枝、天花板或其他支架。

## 檔案內容

| 路徑 | 用途 |
| --- | --- |
| `assets/bat/spritesheet_64.png` | 透明背景標準圖集 |
| `assets/bat/spritesheet_128.png` | 最近鄰 2 倍放大圖集 |
| `assets/bat/frames/*.png` | 24 張獨立 64 × 64 PNG |
| `assets/bat/atlas_64.json`、`atlas_128.json` | 格矩形、動畫順序與每格時間 |
| `assets/bat/atlas-data.js` | 同份 64 px 資料，供離線預覽使用 |
| `preview.gif` | 六組動畫的同步預覽，已加深色展示背景 |
| `demo/index.html` | 透明棋盤背景的動畫檢視頁 |
| `examples/bat-sprite.js` | 可重用 Canvas 動畫播放器 |
| `docs/INTEGRATION.md` | 座標、JSON 與程式整合說明 |
| `docs/ART_SOURCE.md` | 圖像來源與完整生成提示 |
| `docs/VALIDATION.json` | 圖集及資料一致性檢查結果 |
| `source/bat_generated.png` | 原始 AI 生成透明圖，供美術修改 |
| `tools/build.py`、`validate.py` | 可重跑的匯出與檢查工具 |
| `ASSET_USAGE.md`、`LICENSE` | 素材說明及程式授權 |

GIF 是展示用；遊戲請使用透明 PNG。原始生成圖不是固定 64 px 遊戲圖，請使用匯出版本。

## 放進 GitHub

最簡單的方式是將整個 `bat_sprite_pack` 資料夾放在遊戲專案根目錄，再將解壓後的資料夾與檔案上傳。這樣可保留預覽頁的所有相對路徑，且不會覆蓋專案原有 README。

若要統一專案素材路徑，可只將本包的 `assets/bat/` 放進專案的 `assets/bat/`；文件、原圖與範例另外保留。搬動範例或預覽頁時，也要調整其中的相對路徑。

三人協作建議先建立 `assets/add-bat` 分支，上傳並提交後開 Pull Request，由負責整合的人檢查路徑與動畫命名再合併。只上傳 ZIP 會成為下載附件，遊戲無法直接讀取裡面的 PNG。

## 重新匯出與檢查

需要 Python 3.9 以上及 Pillow：

```sh
python -m pip install Pillow
python tools/build.py
python tools/validate.py
```

預覽頁不需要 Python。此包為通用遊戲素材與瀏覽器範例，尚未接入特定遊戲引擎或 GitHub 儲存庫。
