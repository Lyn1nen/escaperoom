"""Validate sprites, frame rectangles and animation references. Pillow required."""
from pathlib import Path
import hashlib
import json
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets' / 'bat'

def validate():
    result = {'passed': True, 'sheets': {}, 'standaloneFrames': 24,
              'checks': ['RGBA transparency', 'safe borders', 'frame rectangles',
                         'standalone slice equality', 'animation references',
                         'nearest-neighbor 2x scaling', 'offline JS data equality']}
    for size in (64, 128):
        atlas = json.loads((ASSETS / f'atlas_{size}.json').read_text(encoding='utf-8'))
        sheet = Image.open(ASSETS / atlas['meta']['image'])
        assert sheet.mode == 'RGBA' and sheet.size == (size * 4, size * 6)
        assert len(atlas['frames']) == 24 and len(atlas['animations']) == 6
        names = []
        for name, animation in atlas['animations'].items():
            assert len(animation['frames']) == 4 and animation['frameDurationMs'] > 0
            names.extend(animation['frames'])
        assert len(set(names)) == 24 and set(names) == set(atlas['frames'])
        for name, entry in atlas['frames'].items():
            f = entry['frame']
            assert f['w'] == f['h'] == size
            assert 0 <= f['x'] <= sheet.width - size and 0 <= f['y'] <= sheet.height - size
            assert f['x'] % size == f['y'] % size == 0
            frame = sheet.crop((f['x'], f['y'], f['x'] + size, f['y'] + size))
            alpha = frame.getchannel('A')
            bounds = alpha.getbbox()
            assert bounds and min(bounds[:2]) >= size // 16
            assert max(bounds[2:]) <= size - size // 16
            low, high = alpha.getextrema()
            assert low == 0 and high >= 240, f'Transparency invalid: {name}'
            if size == 64:
                single = Image.open(ASSETS / 'frames' / name)
                assert single.mode == 'RGBA' and single.size == (64, 64)
                assert single.tobytes() == frame.tobytes(), f'Slice mismatch: {name}'
        result['sheets'][str(size)] = {'width': sheet.width, 'height': sheet.height,
                                     'frames': 24, 'animations': 6}
    small = Image.open(ASSETS / 'spritesheet_64.png')
    big = Image.open(ASSETS / 'spritesheet_128.png')
    assert big.tobytes() == small.resize(big.size, Image.Resampling.NEAREST).tobytes()
    js = (ASSETS / 'atlas-data.js').read_text(encoding='utf-8')
    js_data = json.loads(js.removeprefix('window.BAT_ATLAS = ').rstrip(';\n'))
    assert js_data == json.loads((ASSETS / 'atlas_64.json').read_text(encoding='utf-8'))
    gif = Image.open(ROOT / 'preview.gif')
    duration = 0
    for index in range(gif.n_frames):
        gif.seek(index)
        duration += gif.info['duration']
    assert duration == 2400 and gif.info.get('loop') == 0
    result['gifLoopDurationMs'] = duration
    result['sha256'] = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in sorted(ASSETS.rglob('*')) if p.is_file()}
    (ROOT / 'docs').mkdir(exist_ok=True)
    (ROOT / 'docs' / 'VALIDATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PASS: 2 transparent sheets, 24 slices, 6 animations, JSON and seamless 2400 ms GIF timing.')

if __name__ == '__main__':
    validate()
