"""Export fixed-grid bat assets from AI-generated source. Requires Pillow."""
from pathlib import Path
import json
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets' / 'bat'
STATES = [
    ('fly_down', '向下飛行', 120), ('fly_left', '向左飛行', 120),
    ('fly_right', '向右飛行', 120), ('fly_up', '向上飛行', 120),
    ('hang', '倒掛休息', 300), ('alert', '警戒', 100),
]

def build():
    source = Image.open(ROOT / 'source' / 'bat_generated.png').convert('RGBA')
    ASSETS.mkdir(parents=True, exist_ok=True)
    (ASSETS / 'frames').mkdir(exist_ok=True)
    sheet = Image.new('RGBA', (256, 384))
    for row, (state, label, duration) in enumerate(STATES):
        for col in range(4):
            box = (round(col * source.width / 4), round(row * source.height / 6),
                   round((col + 1) * source.width / 4), round((row + 1) * source.height / 6))
            # Keep the complete cell and add a fixed transparent safety border.
            # This packaging step never paints or reconstructs the character.
            content = source.crop(box).resize((56, 56), Image.Resampling.NEAREST)
            frame = Image.new('RGBA', (64, 64))
            frame.paste(content, (4, 4))
            frame.save(ASSETS / 'frames' / f'{state}_{col:02d}.png')
            sheet.paste(frame, (col * 64, row * 64))
    for size in (64, 128):
        output = sheet if size == 64 else sheet.resize((512, 768), Image.Resampling.NEAREST)
        output.save(ASSETS / f'spritesheet_{size}.png')
        data = {'frames': {}, 'animations': {}, 'meta': {
            'app': 'Escape Room Bat Sprite Pack', 'version': '1.0.0',
            'image': f'spritesheet_{size}.png', 'format': 'RGBA8888',
            'size': {'w': size * 4, 'h': size * 6}, 'scale': '1',
            'grid': {'columns': 4, 'rows': 6, 'frameWidth': size, 'frameHeight': size,
                     'margin': 0, 'spacing': 0}},
            'gameplay': {'origin': {'x': 0.5, 'y': 0.5},
                         'suggestedCollider': {'type': 'circle', 'x': size / 2,
                                               'y': size / 2, 'radius': 9 * size / 64}}}
        for row, (state, label, duration) in enumerate(STATES):
            names = []
            for col in range(4):
                name = f'{state}_{col:02d}.png'
                names.append(name)
                data['frames'][name] = {
                    'frame': {'x': col * size, 'y': row * size, 'w': size, 'h': size},
                    'rotated': False, 'trimmed': False,
                    'spriteSourceSize': {'x': 0, 'y': 0, 'w': size, 'h': size},
                    'sourceSize': {'w': size, 'h': size}, 'pivot': {'x': 0.5, 'y': 0.5}}
            data['animations'][state] = {'label': label, 'row': row,
                'frames': names, 'frameDurationMs': duration, 'loop': True}
        encoded = json.dumps(data, ensure_ascii=False, indent=2)
        (ASSETS / f'atlas_{size}.json').write_text(encoded + '\n', encoding='utf-8')
        if size == 64:
            (ASSETS / 'atlas-data.js').write_text('window.BAT_ATLAS = ' + encoded + ';\n', encoding='utf-8')
    # Render the exported tiles as an opaque GIF preview; this is not game art.
    previews = []
    for step in range(120):
        canvas = Image.new('RGB', (576, 416), '#171622')
        draw = ImageDraw.Draw(canvas)
        for row, (state, label, duration) in enumerate(STATES):
            col = (step * 20 // duration) % 4
            frame = sheet.crop((col * 64, row * 64, (col + 1) * 64, (row + 1) * 64))
            tile = frame.resize((192, 192), Image.Resampling.NEAREST)
            x, y = (row % 3) * 192, (row // 3) * 208
            canvas.paste(tile, (x, y), tile)
            draw.text((x + 12, y + 188), state, fill='#d3b9ef')
        previews.append(canvas)
    previews[0].save(ROOT / 'preview.gif', save_all=True, append_images=previews[1:],
                     duration=20, loop=0, optimize=False, disposal=2)
    print('Exported 2 sheets, 24 slices, JSON atlases and preview GIF.')

if __name__ == '__main__':
    build()
