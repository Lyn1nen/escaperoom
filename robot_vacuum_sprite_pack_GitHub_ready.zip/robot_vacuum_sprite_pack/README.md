# 掃地機器人 Sprite Sheet

適用於 2D 密室逃脫遊戲的像素風掃地機器人。包含四方向移動、待機、清掃、充電、警示共 8 組動畫，每組 4 格，共 32 格。透明背景，可作為巡邏角色、機關提示或可互動物件。

![Sprite Sheet](assets/robot_vacuum/spritesheet_64.png)

## 快速開始

1. 解壓縮素材包，保留內部資料夾結構。
2. 用瀏覽器開啟 `demo/index.html`，選動畫、調整倍率；點一下畫面後用方向鍵或 WASD 移動。
3. 遊戲使用 `assets/robot_vacuum/spritesheet_64.png`，每格 **64 × 64 px**；圖集 **4 欄 × 8 列**，整張 **256 × 512 px**。
4. 圖片匯入設為 Point / Nearest，關閉平滑過濾；依動畫表切片。

也提供 `spritesheet_128.png`：每格 128 × 128 px，整張 512 × 1024 px，以 64 px 版本最近鄰放大，並非新增細節。兩個尺寸均有對應 JSON。

## 動畫對照

列從 0 開始；每列由左至右播放 4 格。圖片座標原點在左上角。

| 動畫名稱 | 列索引 | 格編號（0 起算） | 每格時間 | 用途 |
| --- | ---: | --- | ---: | --- |
| `move_down` | 0 | 0–3 | 120 ms | 向下移動 |
| `move_left` | 1 | 4–7 | 120 ms | 向左移動 |
| `move_right` | 2 | 8–11 | 120 ms | 向右移動 |
| `move_up` | 3 | 12–15 | 120 ms | 向上移動 |
| `idle` | 4 | 16–19 | 240 ms | 待機、青色燈呼吸 |
| `clean` | 5 | 20–23 | 100 ms | 清掃、側刷轉動 |
| `charge` | 6 | 24–27 | 260 ms | 充電、綠燈脈動 |
| `alert` | 7 | 28–31 | 180 ms | 警示、紅燈閃爍 |

全部預設循環。四方向移動列只表現朝向和刷頭動作；實際位移由遊戲程式控制。充電列只有機器人狀態燈，不含充電座。

## 檔案內容

| 路徑 | 內容 |
| --- | --- |
| `assets/robot_vacuum/spritesheet_64.png` | 主要透明背景圖集 |
| `assets/robot_vacuum/spritesheet_128.png` | 2 倍整數放大圖集 |
| `assets/robot_vacuum/atlas_64.json` | 每格矩形與動畫設定 |
| `assets/robot_vacuum/atlas_128.json` | 128 px 對應設定 |
| `assets/robot_vacuum/atlas-data.js` | 離線預覽使用的相同 64 px 設定 |
| `assets/robot_vacuum/frames/*.png` | 32 張獨立 64 × 64 透明 PNG |
| `demo/index.html` | 無外部套件的離線動畫預覽 |
| `examples/robot-vacuum.js` | 可重用的 Canvas 動畫播放器 |
| `docs/INTEGRATION.md` | JSON 欄位、座標、遊戲串接說明 |
| `docs/ART_SOURCE.md` | AI 圖像來源與製作提示 |
| `docs/VALIDATION.json` | 圖集及檔案檢查結果 |
| `tools/validate.py` | 可重跑的素材一致性檢查 |
| `tools/build.py`、`source/` | 原始生成圖與固定格匯出工具 |
| `LICENSE`、`ASSET_USAGE.md` | 範例程式授權與素材使用說明 |

## 放入 GitHub

在現有專案建立素材分支，把本資料夾的內容複製進專案，再提交。已有 README 時，請將本說明另存為 `docs/robot-vacuum/README.md` 並調整圖片相對路徑，避免覆蓋原專案說明。`demo/` 與 `examples/` 可保留，也可只放遊戲用的 `assets/`。

GitHub 網頁可用 **Add file → Upload files** 上傳解壓後的檔案。只上傳 ZIP 會成為下載附件，遊戲無法直接以圖檔路徑讀取裡面的 PNG。

三人協作時建議讓一人負責素材、一人負責互動程式、一人負責整合測試；用 Pull Request 檢查動畫名稱與相對路徑是否一致。

## 檢查

安裝 Python 3 和 Pillow 後，在素材包根目錄執行：

```sh
python -m pip install Pillow
python tools/validate.py
```

預覽頁不需要 Python、網路或安裝套件。本包提供通用圖檔、JSON 與瀏覽器範例，尚未綁定特定遊戲引擎或接入你的 GitHub 專案。
