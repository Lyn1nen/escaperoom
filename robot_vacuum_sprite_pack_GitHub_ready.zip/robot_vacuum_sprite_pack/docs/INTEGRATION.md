# 串接說明

## 圖集與座標

64 px 圖集採固定格：4 欄、8 列、無格間距、無外框留白。每格帶透明安全邊界。128 px 版本的矩形座標與尺寸皆為 2 倍。

```text
x = column × frameWidth
y = row × frameHeight
index = row × 4 + column
```

位置原點為每格中心 `(0.5, 0.5)`。JSON 的 `pivot` 使用 0–1 比例；每格的 `frame`、`spriteSourceSize`、`sourceSize` 使用像素。圖片未旋轉、未裁邊。獨立圖檔與圖集格子像素完全相同。

`atlas_64.json` 的 `frames` / `meta` 採常見 TexturePacker JSON Hash 形式；`animations` 與 `gameplay` 為本包擴充欄位，請由遊戲程式讀取。個別引擎不一定會自動辨識動畫；可改依 README 的列索引手動切片。

## 動畫資料

```js
const a = atlas.animations.clean;
const step = Math.floor(elapsedMs / a.frameDurationMs) % a.frames.length;
const frameName = a.frames[step];
const rect = atlas.frames[frameName].frame;
// drawImage(sheet, rect.x, rect.y, rect.w, rect.h, x, y, width, height)
```

`frames` 是有序的格名稱陣列；`frameDurationMs` 為每格毫秒；`loop` 指循環播放。`atlas-data.js` 是同份資料的瀏覽器全域版本，讓離線 `file://` 預覽不必使用 fetch。

## Canvas 範例

先載入 `atlas-data.js` 和 `examples/robot-vacuum.js`。圖片完成載入後：

```js
const robot = new RobotVacuumSprite(image, ROBOT_VACUUM_ATLAS, 'idle');
robot.play('clean');
// 每次遊戲更新；deltaMs 使用毫秒
robot.update(deltaMs);
robot.draw(ctx, playerX, playerY, 2);
```

同一動畫不要每格反覆呼叫 `play()`，因為它會重設播放時間。`draw()` 的 x/y 是精靈格子的中心。像素風使用整數倍率並將攝影機或繪製座標取整，可減少像素晃動。

## 密室逃脫互動

可將遊戲事件對應至既有動畫：

| 遊戲事件 | 動畫 | 邏輯由遊戲端負責 |
| --- | --- | --- |
| 巡邏 | `move_*` | 路徑、位移、碰撞 |
| 玩家點擊 | `idle` | 顯示調查文字 |
| 開始清掃 | `clean` | 定時、發現物品 |
| 回充完成 | `charge` | 電量、充電區偵測 |
| 感測器觸發 | `alert` | 音效、機關事件 |

`gameplay.suggestedCollider` 是以精靈格子左上角為原點的建議圓形碰撞範圍，只供起始調整；不包含側刷。精靈圖本身不包含尋路、背包、對話、音效、場景或存檔系統。

AI 逐格圖像可能有細小輪廓差異；若專案要求嚴格的逐像素動畫一致性，可在美術編輯器中再調整。此包檢查涵蓋固定格、透明度、PNG 切片、JSON 參照和範例播放器，沒有宣稱已在所有引擎實測。

交付檢查中已驗證全部動畫的計時循環、預覽腳本語法及本地資源路徑；執行環境未提供可啟動的瀏覽器，因此預覽頁尚未完成實際瀏覽器的互動及視覺測試。匯入你的遊戲後仍需依場景比例調整碰撞範圍與播放速度。
