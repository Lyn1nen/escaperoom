+# 圖像製作紀錄

- 製作日期：2026-11-05。
- 圖像使用內建圖像生成功能生成，並修正第二至第四列的機身朝向。
- `source/robot_vacuum_generated.png` 保留最後一版原始透明背景圖，用於後續美術修改；遊戲請使用 `assets/robot_vacuum/` 的規格化 PNG。
- 匯出只進行固定格裁切、最近鄰縮放、排列與資料檔輸出；保留 alpha。64 px 圖集為標準版本，128 px 為其最近鄰 2 倍放大。
- 匯出指令：在根目錄執行 `python tools/build.py`，再執行 `python tools/validate.py`。需要 Pillow。
- 像素風格由 AI 生成，非人工逐像素校稿。

## 初始提示

Use case: stylized-concept. Asset type: production pixel-art sprite sheet for a 2D top-down escape room game. Create ONE perfectly regular sprite atlas on a genuinely transparent background, 4 equal columns by 8 equal rows, exactly 32 isolated sprites; portrait canvas, ideally 1024x2048 so every cell is square. No margins between cells. Each cell has one identical small circular robot vacuum cleaner centered at exactly the same position with generous transparent padding on all sides. Robot design: compact ivory circular shell, dark charcoal bumper, small teal status light, tiny front sensor, two visible side brush tufts, readable crisp pixel blocks with dark outline and limited retro game palette; near overhead view with subtle front rim, no text or face, no background or ground shadow. Consistent scale, camera, silhouette, body center, and lighting across all 32 frames. Strict grid row order from top to bottom: Row 1 moving south toward bottom of image, 4 consecutive brush rotation phases. Row 2 moving west toward left, 4 brush phases. Row 3 moving east toward right, 4 brush phases. Row 4 moving north toward top, 4 brush phases. Row 5 idle facing south, 4 subtle teal indicator brightness pulse phases. Row 6 active cleaning facing south, 4 clearly varied spinning side brush phases. Row 7 charging facing south, 4 soft green indicator pulse phases with NO dock or cable. Row 8 alert facing south, 4 red indicator blink phases, robot intact. Preserve same robot design throughout. Robot body occupies about 62 percent of each square cell width. Frame positions remain locked, animation comes only from brush tips and indicator lights. Hard pixel edges, no anti-aliasing look, no smooth illustration. Absolutely no lettering, numbers, dividers, border, labels, UI, watermark, decor, scenery, batteries, arrows or extra objects.

## 朝向修正提示

Edit this sprite sheet. Preserve the exact 4 column by 8 row grid, 32 robots, fully transparent background, ivory/charcoal/teal pixel art design, cell centers, sizes and all frames in rows 1, 5, 6, 7, 8 unchanged. Correct ONLY robot orientation in rows 2, 3, 4. Row2 (second from top), all four sprites: rotate the ENTIRE ROBOT design 90 degrees CLOCKWISE in the image plane, so the front bumper sensor and teal status light now face the LEFT EDGE of the image. The raised circular lidar turret is offset toward the RIGHT of each robot. Row3: rotate the entire robot 90 degrees COUNTERCLOCKWISE so front bumper sensor and teal light face RIGHT, lidar turret toward LEFT. Row4: rotate entire robot 180 degrees so front bumper sensor and teal light face UP/TOP and lidar turret is at BOTTOM. These must be visibly rotated top-down sprites; do not keep the same forward-facing shell in these rows. Preserve centered coordinates in all cells, generous transparency, no new elements, no labels, no grid lines, no text. Row1 remains facing down. Rows 5-8 remain facing down.

