/* MIT License — Escape Room Sprite Pack contributors */
(function (root) {
  'use strict';
  class RobotVacuumSprite {
    constructor(image, data, animation = 'idle') {
      this.image = image;
      this.data = data;
      this.play(animation);
    }
    play(name) {
      if (!this.data.animations[name]) throw new Error('Unknown animation: ' + name);
      this.animation = name;
      this.elapsed = 0;
    }
    update(deltaMs) {
      if (!Number.isFinite(deltaMs) || deltaMs < 0) return;
      this.elapsed += deltaMs;
    }
    get frameName() {
      const a = this.data.animations[this.animation];
      const step = Math.floor(this.elapsed / a.frameDurationMs);
      return a.frames[a.loop ? step % a.frames.length : Math.min(step, a.frames.length - 1)];
    }
    draw(ctx, x, y, scale = 2) {
      const f = this.data.frames[this.frameName].frame;
      const old = ctx.imageSmoothingEnabled;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(this.image, f.x, f.y, f.w, f.h, x - f.w * scale / 2, y - f.h * scale / 2, f.w * scale, f.h * scale);
      ctx.imageSmoothingEnabled = old;
    }
  }
  root.RobotVacuumSprite = RobotVacuumSprite;
  if (typeof module !== 'undefined' && module.exports) module.exports = RobotVacuumSprite;
})(typeof window !== 'undefined' ? window : globalThis);
