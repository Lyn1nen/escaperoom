window.ROBOT_VACUUM_ATLAS = {
  "frames": {
    "move_down_00.png": {
      "frame": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_down_01.png": {
      "frame": {
        "x": 64,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_down_02.png": {
      "frame": {
        "x": 128,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_down_03.png": {
      "frame": {
        "x": 192,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_left_00.png": {
      "frame": {
        "x": 0,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_left_01.png": {
      "frame": {
        "x": 64,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_left_02.png": {
      "frame": {
        "x": 128,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_left_03.png": {
      "frame": {
        "x": 192,
        "y": 64,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_right_00.png": {
      "frame": {
        "x": 0,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_right_01.png": {
      "frame": {
        "x": 64,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_right_02.png": {
      "frame": {
        "x": 128,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_right_03.png": {
      "frame": {
        "x": 192,
        "y": 128,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_up_00.png": {
      "frame": {
        "x": 0,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_up_01.png": {
      "frame": {
        "x": 64,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_up_02.png": {
      "frame": {
        "x": 128,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "move_up_03.png": {
      "frame": {
        "x": 192,
        "y": 192,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "idle_00.png": {
      "frame": {
        "x": 0,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "idle_01.png": {
      "frame": {
        "x": 64,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "idle_02.png": {
      "frame": {
        "x": 128,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "idle_03.png": {
      "frame": {
        "x": 192,
        "y": 256,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "clean_00.png": {
      "frame": {
        "x": 0,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "clean_01.png": {
      "frame": {
        "x": 64,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "clean_02.png": {
      "frame": {
        "x": 128,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "clean_03.png": {
      "frame": {
        "x": 192,
        "y": 320,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "charge_00.png": {
      "frame": {
        "x": 0,
        "y": 384,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "charge_01.png": {
      "frame": {
        "x": 64,
        "y": 384,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "charge_02.png": {
      "frame": {
        "x": 128,
        "y": 384,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "charge_03.png": {
      "frame": {
        "x": 192,
        "y": 384,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_00.png": {
      "frame": {
        "x": 0,
        "y": 448,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_01.png": {
      "frame": {
        "x": 64,
        "y": 448,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_02.png": {
      "frame": {
        "x": 128,
        "y": 448,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    },
    "alert_03.png": {
      "frame": {
        "x": 192,
        "y": 448,
        "w": 64,
        "h": 64
      },
      "rotated": false,
      "trimmed": false,
      "spriteSourceSize": {
        "x": 0,
        "y": 0,
        "w": 64,
        "h": 64
      },
      "sourceSize": {
        "w": 64,
        "h": 64
      },
      "pivot": {
        "x": 0.5,
        "y": 0.5
      }
    }
  },
  "animations": {
    "move_down": {
      "label": "向下移動",
      "row": 0,
      "frames": [
        "move_down_00.png",
        "move_down_01.png",
        "move_down_02.png",
        "move_down_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "move_left": {
      "label": "向左移動",
      "row": 1,
      "frames": [
        "move_left_00.png",
        "move_left_01.png",
        "move_left_02.png",
        "move_left_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "move_right": {
      "label": "向右移動",
      "row": 2,
      "frames": [
        "move_right_00.png",
        "move_right_01.png",
        "move_right_02.png",
        "move_right_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "move_up": {
      "label": "向上移動",
      "row": 3,
      "frames": [
        "move_up_00.png",
        "move_up_01.png",
        "move_up_02.png",
        "move_up_03.png"
      ],
      "frameDurationMs": 120,
      "loop": true
    },
    "idle": {
      "label": "待機",
      "row": 4,
      "frames": [
        "idle_00.png",
        "idle_01.png",
        "idle_02.png",
        "idle_03.png"
      ],
      "frameDurationMs": 240,
      "loop": true
    },
    "clean": {
      "label": "清掃",
      "row": 5,
      "frames": [
        "clean_00.png",
        "clean_01.png",
        "clean_02.png",
        "clean_03.png"
      ],
      "frameDurationMs": 100,
      "loop": true
    },
    "charge": {
      "label": "充電",
      "row": 6,
      "frames": [
        "charge_00.png",
        "charge_01.png",
        "charge_02.png",
        "charge_03.png"
      ],
      "frameDurationMs": 260,
      "loop": true
    },
    "alert": {
      "label": "警示",
      "row": 7,
      "frames": [
        "alert_00.png",
        "alert_01.png",
        "alert_02.png",
        "alert_03.png"
      ],
      "frameDurationMs": 180,
      "loop": true
    }
  },
  "meta": {
    "app": "Escape Room Robot Vacuum Sprite Pack",
    "version": "1.0.0",
    "image": "spritesheet_64.png",
    "format": "RGBA8888",
    "size": {
      "w": 256,
      "h": 512
    },
    "scale": "1",
    "grid": {
      "columns": 4,
      "rows": 8,
      "frameWidth": 64,
      "frameHeight": 64,
      "margin": 0,
      "spacing": 0
    }
  },
  "gameplay": {
    "origin": {
      "x": 0.5,
      "y": 0.5
    },
    "suggestedCollider": {
      "type": "circle",
      "x": 32.0,
      "y": 32.0,
      "radius": 19.0
    }
  }
};
