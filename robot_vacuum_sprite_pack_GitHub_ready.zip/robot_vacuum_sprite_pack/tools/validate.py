"""Check game-facing PNGs, their JSON rectangles and independent slices."""
from pathlib import Path
import hashlib
import json
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets' / 'robot_vacuum'

def validate():
    counts = {}
    for size in (64, 128):
        data = json.loads((ASSETS / f'atlas_{size}.json').read_text(encoding='utf-8'))
        sheet = Image.open(ASSETS / data['meta']['image'])
        assert sheet.mode == 'RGBA', 'PNG must preserve transparency'
        assert sheet.size == (4 * size, 8 * size), 'Wrong sheet dimensions'
        assert len(data['frames']) == 32 and len(data['animations']) == 8
        all_names = []
        for state, animation in data['animations'].items():
            assert animation['frameDurationMs'] > 0
            assert len(animation['frames']) == 4
            all_names.extend(animation['frames'])
        assert len(set(all_names)) == 32 and set(all_names) == set(data['frames'])
        for name, entry in data['frames'].items():
            f = entry['frame']
            assert f['w'] == f['h'] == size
            assert f['x'] % size == f['y'] % size == 0
            tile = sheet.crop((f['x'], f['y'], f['x'] + size, f['y'] + size))
            alpha = tile.getchannel('A')
            box = alpha.getbbox()
            assert box is not None, f'Empty frame: {name}'
            assert 0 < box[0] < box[2] < size and 0 < box[1] < box[3] < size, f'Frame touches boundary: {name}'
            alpha_min, alpha_max = alpha.getextrema()
            assert alpha_min == 0 and alpha_max >= 250, f'Invalid transparent sprite: {name}'
            if size == 64:
                single = Image.open(ASSETS / 'frames' / name)
                assert single.size == (64, 64) and single.mode == 'RGBA'
                assert single.tobytes() == tile.tobytes(), f'Slice mismatch: {name}'
        counts[str(size)] = {'sheetWidth': sheet.width, 'sheetHeight': sheet.height,
                             'frames': 32, 'animations': 8, 'transparentSafeBorder': True}
    small = Image.open(ASSETS / 'spritesheet_64.png')
    big = Image.open(ASSETS / 'spritesheet_128.png')
    assert big.tobytes() == small.resize(big.size, Image.Resampling.NEAREST).tobytes()
    atlas_json = json.loads((ASSETS / 'atlas_64.json').read_text(encoding='utf-8'))
    js = (ASSETS / 'atlas-data.js').read_text(encoding='utf-8')
    assert json.loads(js.removeprefix('window.ROBOT_VACUUM_ATLAS = ').rstrip(';\n')) == atlas_json
    hashes = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in sorted(ASSETS.rglob('*')) if path.is_file()}
    result = {'passed': True, 'sheets': counts, 'standaloneFrames': 32,
              'nearestNeighbor2xVerified': True, 'browserDataMatchesJson': True,
              'sha256': hashes}
    (ROOT / 'docs' / 'VALIDATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PASS: 2 RGBA sheets, 32 slices, 8 animations; borders, coordinates, alpha and JSON verified.')

if __name__ == '__main__':
    validate()
