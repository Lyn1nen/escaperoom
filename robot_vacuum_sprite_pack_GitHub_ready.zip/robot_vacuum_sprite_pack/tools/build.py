"""Re-export the generated artwork as fixed-grid game assets (Pillow required)."""
from pathlib import Path
import json
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets' / 'robot_vacuum'
STATES = [
    ('move_down', '向下移動', 120), ('move_left', '向左移動', 120),
    ('move_right', '向右移動', 120), ('move_up', '向上移動', 120),
    ('idle', '待機', 240), ('clean', '清掃', 100),
    ('charge', '充電', 260), ('alert', '警示', 180),
]

def build():
    source = Image.open(ROOT / 'source' / 'robot_vacuum_generated.png').convert('RGBA')
    ASSETS.mkdir(parents=True, exist_ok=True)
    (ASSETS / 'frames').mkdir(exist_ok=True)
    small = Image.new('RGBA', (256, 512))
    for row in range(8):
        for col in range(4):
            # Round each shared boundary once; the generation source may have
            # non-integer cell dimensions. Preserve alpha and use nearest pixels.
            box = (round(col * source.width / 4), round(row * source.height / 8),
                   round((col + 1) * source.width / 4), round((row + 1) * source.height / 8))
            frame = source.crop(box).resize((64, 64), Image.Resampling.NEAREST)
            name = f'{STATES[row][0]}_{col:02d}.png'
            frame.save(ASSETS / 'frames' / name)
            small.paste(frame, (col * 64, row * 64))
    for size in (64, 128):
        image = small if size == 64 else small.resize((512, 1024), Image.Resampling.NEAREST)
        image.save(ASSETS / f'spritesheet_{size}.png')
        data = {'frames': {}, 'animations': {}, 'meta': {
            'app': 'Escape Room Robot Vacuum Sprite Pack', 'version': '1.0.0',
            'image': f'spritesheet_{size}.png', 'format': 'RGBA8888',
            'size': {'w': size * 4, 'h': size * 8}, 'scale': '1',
            'grid': {'columns': 4, 'rows': 8, 'frameWidth': size, 'frameHeight': size,
                     'margin': 0, 'spacing': 0}},
            'gameplay': {'origin': {'x': 0.5, 'y': 0.5},
                         'suggestedCollider': {'type': 'circle', 'x': size / 2,
                                               'y': size / 2, 'radius': 19 * size / 64}}}
        for row, (state, label, duration) in enumerate(STATES):
            names = []
            for col in range(4):
                name = f'{state}_{col:02d}.png'
                names.append(name)
                data['frames'][name] = {
                    'frame': {'x': col * size, 'y': row * size, 'w': size, 'h': size},
                    'rotated': False, 'trimmed': False,
                    'spriteSourceSize': {'x': 0, 'y': 0, 'w': size, 'h': size},
                    'sourceSize': {'w': size, 'h': size}, 'pivot': {'x': 0.5, 'y': 0.5}}
            data['animations'][state] = {'label': label, 'row': row,
                                         'frames': names, 'frameDurationMs': duration, 'loop': True}
        encoded = json.dumps(data, ensure_ascii=False, indent=2)
        (ASSETS / f'atlas_{size}.json').write_text(encoded + '\n', encoding='utf-8')
        if size == 64:
            (ASSETS / 'atlas-data.js').write_text('window.ROBOT_VACUUM_ATLAS = ' + encoded + ';\n', encoding='utf-8')
    print('Exported 2 sheets, 32 frames, 2 JSON atlases and browser data.')

if __name__ == '__main__':
    build()
